var_brand <- function(Y_tot, Y_training, labels_tot, labels_training, p,J,Tr,n_iter,tol,gamma,a_dir_k, mu_0_DP, nu_0_DP,
                      lambda_0_DP, PSI_0_DP,mu_0_MIX,nu_0_MIX,lambda_0_MIX,
                      PSI_0_MIX,PSI_0_MIX_FACTOR,M,Phi_m_k,eta_k,a_k_beta,b_k_beta,mu_var_DP,nu_var_DP,
                      lambda_var_DP,PSI_var_DP,mu_VAR_MIX,nu_VAR_MIX,lambda_VAR_MIX,PSI_VAR_MIX) {
  
  library(rrcov)
  
  ####  FIT - STEP 1  ####
  # Generate Robust Parameters
  robust_mean <- c()
  robust_inv_cov_mat <- list()
  
  i = 1;
  while(i<=J){
    index = which(labels_training==i)
    robust_mean <- rbind(robust_mean, CovMcd(Y_training[index,])$center)
    robust_inv_cov_mat[[i]] <- CovMcd(Y_training[index,])$cov
    i = i+1
  }
  robust_mean
  robust_inv_cov_mat
  
  # Update model
  # mu_0_MIX
  if (is.null(mu_0_MIX)){
     mu_0_MIX = t(robust_mean)
  }#EVENTUALMENTE TRASPOSTA
  
  # PSI_0_MIX
  if (is.null(PSI_0_MIX)){
    PSI_0_MIX = robust_inv_cov_mat
    for(i in 1:length(PSI_0_MIX)){
      PSI_0_MIX[[i]] = PSI_0_MIX_FACTOR *PSI_0_MIX[[i]]
    }
  }
  
  # mu_VAR_MIX
  if (is.null(mu_VAR_MIX)){
    mu_VAR_MIX = mu_0_MIX
  }
  
  # PSI_VAR_MIX
  if (is.null(PSI_VAR_MIX)){
      PSI_VAR_MIX = PSI_0_MIX
  }
  
  ####  FIT - STEP 2  ####
  library(foobar2)
  result = foobar2::VarBrand(as.matrix(Y_tot), p,J,Tr,n_iter,tol,gamma,a_dir_k, mu_0_DP, nu_0_DP,
                        lambda_0_DP, PSI_0_DP,mu_0_MIX,nu_0_MIX,lambda_0_MIX,
                        PSI_0_MIX,M,Phi_m_k,eta_k,a_k_beta,b_k_beta,mu_var_DP,nu_var_DP,
                        lambda_var_DP,PSI_var_DP,mu_VAR_MIX,nu_VAR_MIX,lambda_VAR_MIX,PSI_VAR_MIX)
  
  
  Phi_m_k_l = result$Phi_m_k
  mu_VAR_MIX_updated  = result$mu_VAR_MIX
  mu_var_DP_updated  = result$mu_var_DP
  elbo_values = result$elbo_values

  
  ####  RESULTS  ####
  #Generate labels_pred
  #install.packages("ramify")
  library("ramify")
  labels_pred = argmax(Phi_m_k_l, rows = TRUE)
  
  #Clusters' size
  print("Clusters\' size")
  unique_clusters = unique(labels_pred)
  
  for(i in unique_clusters){
    toprint = paste('cluster ', i, ': ',sum(labels_pred == i))
    print(toprint)
  }
  
  # #PLOT CLUSTERS (only for p== 2)
  if(p==2){
    df_Y_tot <- data.frame(x=Y_tot[,1], y = Y_tot[,2])

    library(ggplot2)
    plot_clusters= ggplot(df_Y_tot,aes(x,y, color = as.factor(labels_pred)))+geom_point()

    for(i in 1:dim(robust_mean)[1]){
      print(i)
      plot_clusters = plot_clusters+ annotate("point", x=robust_mean[i,1],y=robust_mean[i,2],colour="red",shape = 20,
                      size = 5)
    }

    for(i in 1:dim(robust_mean)[1]){
      print(i)
      plot_clusters= plot_clusters+ annotate("point", x=mu_VAR_MIX_updated[1,i],y=mu_VAR_MIX_updated[2,i],colour="green",shape = 17,
                      size = 2)
    }

    for(i in 1:dim(robust_mean)[1]){
      print(i)
      plot_clusters= plot_clusters+ annotate("point", x=mu_var_DP_updated[1,i],y=mu_var_DP_updated[2,i],colour="orange",shape = 18,
                      size = 3)
    }
    plot(plot_clusters)
  }


  # ELBO
  print("elbo_values:")
  print(elbo_values)
  
  # plot ELBO
  #install.packages("ggplot2")
  library(ggplot2)
  theme_set(
    theme_classic() +
      theme(legend.position = "top")
  )
  
  
  # Create data for chart
  val <-data.frame(iteration=1:length(elbo_values),
                   elbo=elbo_values)
  
  # Basic Line
  plot_elbo = ggplot(data=val, aes(x=iteration, y=elbo, group=1)) +
    geom_line()+
    geom_point()
  
  plot(plot_elbo)
  
  # ARI
  #install.packages("aricode")
  library(aricode)
  ari = ARI(labels_pred,labels_tot)
  print("ARI:")
  print(ari)
  
  result = list()
  result$labels_pred = labels_pred
  result$ari = ari
  
  return(result)
}