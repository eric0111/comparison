#EDIT CODE
-from clion open foobar2
edit cpp code

-from rstudio open foobar2/main.r
edit  main.r

#BUILD CODE - RSTUDIO
In Rstudio:

install.packages("Rcpp")
library(Rcpp)
install.packages("RcppEigen")
library(RcppEigen)

In terminal:
//go to foobar2 path
cd foobar2_path

//compile,build,install
Rscript -e 'Rcpp::compileAttributes()'
R CMD build .
R CMD INSTALL foobar2_1.0.tar.gz


#RUN CODE

install.packages("foobar2")
library("foobar2")

//ok se errori, cliccare si se chiede di riavviare sessione
select and run main.R

se crasha, da terminale usare Rscript al posto di Rstudio:
Rscript /Users/eb/CLionProjects/VariationalBRAND-cpp/foobar2/src/main.R