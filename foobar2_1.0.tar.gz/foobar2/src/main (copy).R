#setwd("/home/eb/CLionProjects/VariationalBRAND-cpp")
#setwd("/Users/eb/CLionProjects/VariationalBRAND-cpp")
setwd("C:/Users/user/Desktop/Paperino/Gitrepo/VariationalBRAND-cpp")
set.seed(27011999)


#install.packages("Rcpp")
library(Rcpp)
#install.packages("rrcov")
library(rrcov)

#FILE PATHS
LABELS_TOT_PATH = "./bin/data_n950_p2/labels_tot_1_2.csv"
LABELS_TRAINING_PATH = "./bin/data_n950_p2/labels_training_1_2.csv"
Y_TOT_PATH = "./bin/data_n950_p2/Y_1_2.csv"
Y_TRAINING_PATH = "./bin/data_n950_p2/Y_training_1_2.csv"

#LOAD DATASETS
labels_tot <- read.csv(LABELS_TOT_PATH)
labels_training <- read.csv(LABELS_TRAINING_PATH)
Y_tot <- read.csv(Y_TOT_PATH)
Y_training <- read.csv(Y_TRAINING_PATH)

#SPECIFY USER INPUT
#Numero di componenti
p = dim(Y_tot)[2]

#Numero di classi nel training set
J = dim(unique(labels_training))[1]

#Numero di classi massime nel Dirichlet Process
Tr = 20

#Num iteration and tolerance cavi
n_iter = 2000
tol = 1e-5

##ROBUST PARAMETERS
robust_mean <- c()
robust_inv_cov_mat <- list()

i = 1;
while(i<=J){
  index = which(labels_training==i)
  robust_mean <- rbind(robust_mean, CovMcd(Y_training[index,])$center)
  robust_inv_cov_mat[[i]] <- CovMcd(Y_training[index,])$cov
  i = i+1
}
robust_mean
robust_inv_cov_mat

#HYPERPARAMETERS
#gamma -> parametro dello Stick Breaking -> scalare
gamma = 5

#a_dir_k -> vettore delle componenti della Dir0ichlet -> vettore di (J+1) componenti
a_dir_k = rep(1, J + 1)

#nIW_DP_0
# 	mu_0_DP -> vettore (p) componenti
# 	nu_0_DP -> scalare
# 	lambda_0_DP -> scalare
# 	PSI_0_DP -> Matrice (pxp)

mu_0_DP = rep(0, p)

nu_0_DP = c(p+2)

lambda_0_DP = c(1)

PSI_0_DP = 10*matrix(diag(p), nrow = p, ncol = p)


#NIW_MIX_0
# mu_0_MIX -> matrice (pxJ)
#           -> colonna per colonna ci sono le medie delle componenti della mistura
#               (mu_0_MIX[:,i] -> media della (i+1)-esima NIW della mistura)
#
# nu_0_MIX -> vettore (J) componenti
#               (nu_0_MIX[i] = nu_0 della (i+1) esima NIW della mistura)
#
# lambda_0_MIX -> vettore (J) componenti
#               (lambda_0_MIX[i] = lambda_0 della (i+1)  esima NIW della mistura)
#
# PSI_0_MIX -> vettore di matrici (Jxpxp), sostanzialmente un ndarray
#           -> PSI_0_MIX[i,:,:] = Matrice PSI della (i+1)esima NIW della mistura

mu_0_MIX = robust_mean#EVENTUALMENTE TRASPOSTA

nu_0_MIX = rep(50+p+1,J)

lambda_0_MIX = rep(50,J)

PSI_0_MIX = robust_inv_cov_mat
for(i in 1:length(PSI_0_MIX)){
  PSI_0_MIX[[i]] = 50*PSI_0_MIX[[i]]
}

#VARIATIONAL PARAMETERS
M = dim(Y_tot)[1]+1
Phi_m_k = matrix(1, M, J + Tr) * (1 / (J + T))

eta_k = a_dir_k

a_k_beta = rep(1, Tr - 1)

b_k_beta = rep(gamma, Tr - 1)


# NIW_DP_VAR
# mu_var_DP -> matrice (Txp)
# -> colonna per colonna ci sono le medie delle componenti della misturaDP
#    (mu_var_DP[:,i] -> media della (i+1)-esima NIW della misturaDP)

# nu_var_DP -> vettore (T) componenti
# (nu_var_MIX[i] = nu_var della (i+1) esima NIW della misturaDP)

# lambda_var_DP -> vettore (T) componenti
# (lambda_var_DP[i] = lambda_var della (i+1) esima NIW della misturaDP)

# PSI_var_DP -> vettore di matrici (Txpxp), sostanzialmente un ndarray
# -> PSI_var_DP[i,:,:] = Matrice PSI della (i+1)esima NIW della misturaDP

mu_var_DP <- matrix(1, Tr, p)# t(kmeans(Y_tot, T)$center) #eventualmente trasposto


for(i in 1:Tr){
  for(j in 1:p){
    mu_var_DP[i,j] = rnorm(n=1, mean = 0, sd = 5)
  }
}

nu_var_DP = rep(nu_0_DP, Tr)

lambda_var_DP = rep(lambda_0_DP, Tr)

PSI_var_DP = list()
for (i in 1:Tr) PSI_var_DP[[i]] = PSI_0_DP

#NIW_MIX_VAR:
# mu_VAR_MIX -> matrice (Jxp)
#           -> colonna per colonna ci sono le medie delle componenti della mistura
#               (mu_VAR_MIX[:,i] -> media della (i+1)-esima NIW della mistura)
#
# nu_VAR_MIX -> vettore (J) componenti
#               (nu_VAR_MIX[i] = nu_0 della (i+1) esima NIW della mistura)
#
# lambda_VAR_MIX -> vettore (J) componenti
#               (lambda_VAR_MIX[i] = lambda_0 della (i+1)  esima NIW della mistura)
#
# PSI_VAR_MIX -> vettore di matrici (Jxpxp), sostanzialmente un ndarray
#           -> PSI_VAR_MIX[i,:,:] = Matrice PSI della (i+1)esima NIW della mistura

mu_VAR_MIX = mu_0_MIX

nu_VAR_MIX = nu_0_MIX

lambda_VAR_MIX = lambda_0_MIX

PSI_VAR_MIX = PSI_0_MIX

###RUN
#In terminal:
#cd /home/eb/CLionProjects/VariationalBRAND-cpp/foobar2
#Rscript -e 'Rcpp::compileAttributes()'
#R CMD build .
#R CMD INSTALL foobar2_1.0.tar.gz
#install.packages("foobar2")
library(foobar2)


L = foobar2::VarBrand(as.matrix(Y_tot), p,J,Tr,n_iter,tol,gamma,a_dir_k, mu_0_DP, nu_0_DP,
                lambda_0_DP, PSI_0_DP,mu_0_MIX,nu_0_MIX,lambda_0_MIX,
                PSI_0_MIX,M,Phi_m_k,eta_k,a_k_beta,b_k_beta,mu_var_DP,nu_var_DP,
                lambda_var_DP,PSI_var_DP,mu_VAR_MIX,nu_VAR_MIX,lambda_VAR_MIX,PSI_VAR_MIX)


#print(L)
Phi_m_k_l = L$Phi_m_k
mu_VAR_MIX_updated  = L$mu_VAR_MIX
mu_var_DP_updated  = L$mu_var_DP
elbo_values = L$elbo_values
print(elbo_values)

for(i in 1:(length(elbo_values)-1)){
  if(elbo_values[i+1]<elbo_values[i])
    print(i)
}

#
#Generate labels_pred
# labels_pred = generate_labels_pred(variational_parameters, Y)
# labels_pred = []
# for i in range(Y.shape[0]):
#   labels_pred.append(jnp.argmax(variational_parameters.phi_m_k[i, :]))

#install.packages("ramify")
library("ramify")

labels_pred = argmax(Phi_m_k_l, rows = TRUE)

# print('Clusters\' numerosity')
# #print(labels_pred)
# unique_clusters = np.unique(np.array(labels_pred))
# num_clusters = len(unique_clusters)
#
# for i in unique_clusters:
#   print('cluster ', i, ': ',labels_pred.count(i))
unique_clusters = unique(labels_pred)

for(i in range(unique_clusters)){
  toprint = paste('cluster ', i, ': ',sum(labels_pred == i))
  print(toprint)
}

#plot if p = 2 todo
if(p==2){
  df_Y_tot <- data.frame(x=Y_tot[,1], y = Y_tot[,2])
  
  library(ggplot2)
  p = ggplot(df_Y_tot,aes(x,y))+geom_point()
  
  for(i in 1:dim(robust_mean)[1]){
    print(i)
    p =p + annotate("point", x=robust_mean[i,1],y=robust_mean[i,2],colour="red",shape = 20,
                    size = 7)
  }
  
  for(i in 1:dim(robust_mean)[1]){
    print(i)
    p =p + annotate("point", x=mu_VAR_MIX_updated[i,1],y=mu_VAR_MIX_updated[i,2],colour="green",shape = 17,
                    size = 7)
  }
  
  for(i in 1:dim(robust_mean)[1]){
    print(i)
    p =p + annotate("point", x=mu_var_DP_updated[i,1],y=mu_var_DP_updated[i,2],colour="orange",shape = 18,
                    size = 6)
  }
  p
}


#plot elbo
#install.packages("ggplot2")
library(ggplot2)
theme_set(
  theme_classic() +
    theme(legend.position = "top")
)


# Create data for chart
val <-data.frame(iteration=1:length(elbo_values),
                 elbo=elbo_values)

# Basic Line
ggplot(data=val, aes(x=iteration, y=elbo, group=1)) +
  geom_line()+
  geom_point()


##ARI
#install.packages("aricode")
library(aricode)
ARI(labels_pred,labels_tot)

##todo
#-tictoc
#-save results
#-suite di tests

