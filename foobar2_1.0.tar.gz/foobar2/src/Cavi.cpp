//
// Created by marta on 25/03/2022.
//

#include "Cavi.h"

std::vector<double> Cavi::start(){
//    std::cout << std::endl <<"CAVI" << std::endl;
    std::vector<double> elbo_values;

    unsigned i = 0;
    bool stop = false;
    std::vector<double> elbo_prec(13);

    for(unsigned k = 0; k < 13; k++) elbo_prec[i] = 0;

    while((i<alg_par.n_iter) and (!stop)) {
        update_parameters(Y_tot, vb_data, alg_par);
        elbo_values.push_back(elbo_calculator(Y_tot, vb_data,alg_par, elbo_prec));

        std::cout <<"iter "<< i << " elbo: " << elbo_values[i] << std::endl;

        if ((i > 0) and (abs(elbo_values[i] - elbo_values[i - 1]) < alg_par.tol)) {
             std::cout  << "\nConvergence of elbo in "<< i << " iterations" << std::endl;
             std::cout  << "Last increment: " << abs(elbo_values[i] - elbo_values[i - 1]) << std::endl;
             stop = true;
        }
        i += 1;
    }

    return elbo_values;
}

void update_dirichlet(VariationalParameters & vb_data, const AlgorithmParameters & alg_par){
    unsigned i = 0;
    vb_data.eta_k[i] = alg_par.a_dir_k[i] + vb_data.Phi_m_k.rightCols(alg_par.T).sum();
    for(i = 1; i <=alg_par.J; i++){
        vb_data.eta_k[i] = alg_par.a_dir_k[i] + vb_data.Phi_m_k.col(i-1).sum();
    }
/*    if(isnan(vb_data.eta_k)){
        std::cout << "eta_k is NaN" << std::endl;
    }*/
}

void update_betas(VariationalParameters & vb_data, const AlgorithmParameters & alg_par){
    for(unsigned i = 0; i<alg_par.T-1; i++){
        vb_data.a_k_beta[i] = 1 + vb_data.Phi_m_k.col(i+alg_par.J).sum();
        vb_data.b_k_beta[i] = alg_par.gamma + vb_data.Phi_m_k.rightCols(alg_par.T - (i+1)).sum();
    }
/*    if(isnan(vb_data.a_k_beta)){
        std::cout << "a_k_beta is NaN" << std::endl;
    }
    if(isnan(vb_data.b_k_beta)){
        std::cout << "b_k_beta is NaN" << std::endl;
    } */
}

void update_NIW_MIX(const Eigen::MatrixXd & Y_tot, VariationalParameters & vb_data, const AlgorithmParameters & alg_par){
    double phi_m_k_sum = 0.;
    double newlam = 0.;
    double coef_comp3_PSI = 0.;

    Eigen::VectorXd y_sum;
    Eigen::VectorXd newmu_num;
    Eigen::VectorXd y_bar;
    Eigen::MatrixXd PSI_temp;
    Eigen::VectorXd y_centered;
    Eigen::VectorXd ybar_centered;
    Eigen::MatrixXd diad;

    for(unsigned i = 0; i<alg_par.J; i++){
        phi_m_k_sum = vb_data.Phi_m_k.col(i).sum();

/*        if(isnan(phi_m_k_sum)){
            std::cout << "PHI_M_K_sum is NAN" << std::endl;
        } */

        newlam = alg_par.lambda_0_MIX(i) + phi_m_k_sum;
        vb_data.lambda_VAR_MIX(i) = newlam;
        vb_data.nu_VAR_MIX(i) = alg_par.nu_0_MIX(i) + phi_m_k_sum;

        y_sum = vb_data.Phi_m_k(0, i)*Y_tot.row(0);
        for(unsigned m = 1; m < alg_par.M; m++){
            y_sum =  y_sum + vb_data.Phi_m_k(m, i)*Y_tot.row(m).transpose();
        }

/*        if(isnan(y_sum.sum())){
            std::cout << "y_sum is NaN" << std::endl;
        } */

        newmu_num = alg_par.lambda_0_MIX(i)*alg_par.mu_0_MIX.col(i) + y_sum;
        vb_data.mu_VAR_MIX.col(i) = newmu_num/newlam;

/*        if(isnan(vb_data.mu_VAR_MIX.col(i).sum())){
            std::cout << "mean MIX is NaN" << std::endl;
        } */
        y_bar = y_sum/phi_m_k_sum;
        PSI_temp = alg_par.PSI_0_MIX[i];

        for(unsigned m = 0; m < alg_par.M; m++){
            y_centered = Y_tot.row(m).transpose() - y_bar;
            diad = y_centered*y_centered.transpose();
            diad = vb_data.Phi_m_k(m,i)*diad;
            PSI_temp = PSI_temp + diad ;
        }
        ybar_centered = y_bar - alg_par.mu_0_MIX.col(i);
        coef_comp3_PSI = phi_m_k_sum*alg_par.lambda_0_MIX(i)/newlam;
        PSI_temp += coef_comp3_PSI*ybar_centered*ybar_centered.transpose();
        vb_data.PSI_VAR_MIX_inv[i] = PSI_temp.inverse();
        //std::cout << "PSI_var_MIX: \n" << vb_data.PSI_VAR_MIX_inv[i] << std::endl;
/*        if(isnan(vb_data.PSI_VAR_MIX_inv[i].sum())){
            std::cout << "cov MIX is NaN" << std::endl;
        } */
    }
}

void update_NIW_DP(const Eigen::MatrixXd & Y_tot, VariationalParameters & vb_data, const AlgorithmParameters & alg_par){
    double phi_m_k_sum = 0.;
    double newlam = 0.;
    double coef_comp3_PSI = 0.;

    Eigen::VectorXd y_sum;
    Eigen::VectorXd newmu_num;
    Eigen::VectorXd y_bar;
    Eigen::MatrixXd PSI_temp;
    Eigen::VectorXd y_centered;
    Eigen::VectorXd ybar_centered;
    Eigen::MatrixXd diad;

    for(unsigned i = 0; i<alg_par.T; i++){
        phi_m_k_sum = vb_data.Phi_m_k.col(i+alg_par.J).sum();

        newlam = alg_par.lambda_0_DP + phi_m_k_sum;
        vb_data.lambda_var_DP(i) = newlam;
        vb_data.nu_var_DP(i) = alg_par.nu_0_DP + phi_m_k_sum;

// questo if serve? è giusto? comunque poi assegnamo dei valori con le solite formule
// forse non si entra nel for
        if(phi_m_k_sum == 0){
            vb_data.mu_var_DP.col(i) = alg_par.mu_0_DP;
            vb_data.PSI_var_DP_inv[i] = alg_par.PSI_0_DP;
            std::cout << "PHI_M_K_sum is 0" << std::endl;
        }


/*        if(isnan(phi_m_k_sum)){
            std::cout << "PHI_M_K_sum is NAN" << std::endl;
        } */

        y_sum = vb_data.Phi_m_k(0, i+alg_par.J)*Y_tot.row(0);
        for(unsigned m = 1; m < alg_par.M; m++){
            y_sum += vb_data.Phi_m_k(m, i+alg_par.J)*Y_tot.row(m).transpose();
        }

        newmu_num = alg_par.lambda_0_DP*alg_par.mu_0_DP + y_sum;
        vb_data.mu_var_DP.col(i) = newmu_num/newlam;

/*        if(isnan(vb_data.mu_var_DP.col(i).sum())){
            std::cout << "mean DP is NaN" << std::endl;
        } */
        y_bar = y_sum/phi_m_k_sum;
        PSI_temp = alg_par.PSI_0_DP;
        for(unsigned m = 0; m < alg_par.M; m++){
            y_centered = Y_tot.row(m).transpose() - y_bar;
            diad = y_centered*y_centered.transpose();
            diad = vb_data.Phi_m_k(m,i+alg_par.J)*diad;
            PSI_temp = PSI_temp + diad ;
        }

        ybar_centered = y_bar - alg_par.mu_0_DP;
        coef_comp3_PSI = phi_m_k_sum*alg_par.lambda_0_DP/newlam;
        PSI_temp += coef_comp3_PSI*ybar_centered*ybar_centered.transpose();
        vb_data.PSI_var_DP_inv[i] = PSI_temp.inverse();
        //std::cout << "PSI_var_DP: \n" << vb_data.PSI_var_DP_inv[i] << std::endl;
/*        if(isnan(vb_data.PSI_var_DP_inv[i].sum())){
            std::cout << "cov DP is NaN" << std::endl;
        } */
    }
}

void update_clusters(const Eigen::MatrixXd& Y_tot,
                     VariationalParameters& vb_data,
                     const AlgorithmParameters& alg_par){
    Eigen::VectorXd Y_centered;
    Eigen::VectorXd matxvec_temp;

    double eta_bar = vb_data.eta_k.sum();
    double dig_eta_bar = Eigen::numext::digamma(eta_bar);

    double elogpi = 0.;
    double diga_sum = 0.;
    double logdet = 0.;

    double contr1 = 0.;
    double poverlam = 0.;

    double elogv = 0.;
    double cumsum_betas = 0.;

    double normalizer = 0.;
    double x_star = 0.;

/*    if(isnan(dig_eta_bar)){
        dig_eta_bar = 0;
        std::cout << "di_eta_bar is NaN" << std::endl;
    } */

    for(unsigned k = 0; k < alg_par.J; k++){
        elogpi = Eigen::numext::digamma(vb_data.eta_k(k+1)) - dig_eta_bar;

        diga_sum = 0.;
        for(unsigned l = 1; l <= alg_par.p;l++){
            diga_sum += Eigen::numext::digamma((0.5*(vb_data.nu_VAR_MIX(k) + 1 - double(l))));
        }

        logdet = std::log(vb_data.PSI_VAR_MIX_inv[k].determinant());

        poverlam = double(alg_par.p) / vb_data.lambda_VAR_MIX(k);

        for(unsigned m = 0; m < alg_par.M; m++) {
            Y_centered = Y_tot.row(m).transpose() - vb_data.mu_VAR_MIX.col(k);
            matxvec_temp = (vb_data.PSI_VAR_MIX_inv[k])*Y_centered;
            contr1 = Y_centered.transpose()*matxvec_temp;
            contr1 = vb_data.nu_VAR_MIX(k)*contr1;

            vb_data.Phi_m_k(m,k) = elogpi + 0.5*(diga_sum + logdet - contr1 - poverlam);
        }
    }

    elogpi = Eigen::numext::digamma(vb_data.eta_k(0)) - dig_eta_bar;

    for(unsigned k = 0; k < alg_par.T; k++){
        elogv = 0.;

        if(k < alg_par.T-1) {
            elogv += Eigen::numext::digamma(vb_data.a_k_beta(k)) - Eigen::numext::digamma((vb_data.a_k_beta(k) + vb_data.b_k_beta(k)));
        }

        if(k > 0){
            cumsum_betas += Eigen::numext::digamma(vb_data.b_k_beta(k-1)) - Eigen::numext::digamma((vb_data.a_k_beta(k-1) + vb_data.b_k_beta(k-1)));
        }
        elogv += cumsum_betas;
/*        if(isnan(e_log_w)){
            std::cout << "ELOGW IS NAN" << std::endl;
        } */

        diga_sum = 0.;
        for(unsigned l = 1; l <= alg_par.p;l++){
            diga_sum += Eigen::numext::digamma((0.5*(vb_data.nu_var_DP(k) + 1 - double(l))));
        }

/*        if(isnan(diga_sum)){
            std::cout << "DIGASUM IS NAN" << std::endl;
        } */

        logdet = std::log(vb_data.PSI_var_DP_inv[k].determinant());
/*        if(isnan(logdet)){
            std::cout << "LOGDET IS NAN" << std::endl;
        } */

        poverlam = double(alg_par.p) / vb_data.lambda_var_DP(k);

        for(unsigned m = 0; m < alg_par.M; m++) {
            Y_centered = Y_tot.row(m).transpose() - vb_data.mu_var_DP.col(k);
            matxvec_temp = (vb_data.PSI_var_DP_inv[k])*Y_centered;
            contr1 = Y_centered.transpose()*matxvec_temp;
            contr1 = vb_data.nu_var_DP(k)*contr1;

            vb_data.Phi_m_k(m,k + alg_par.J) = elogpi + elogv + 0.5*(diga_sum + logdet - contr1 - poverlam);
        }
    }

    for(unsigned m = 0; m < alg_par.M; m++){
        normalizer = 0.;
        x_star = vb_data.Phi_m_k.row(m).maxCoeff();
        for(unsigned k = 0; k<(alg_par.J + alg_par.T); k++){
            normalizer += std::exp(vb_data.Phi_m_k(m, k) - x_star);
        }
        normalizer = x_star + std::log(normalizer);

//        if(isnan(normalizer)){
//            std::cerr << "NaN in Phi_m_k pre normalization" << std::endl;
//        }
        for(unsigned k = 0; k<(alg_par.J + alg_par.T); k++){
            vb_data.Phi_m_k(m,k) = std::exp(vb_data.Phi_m_k(m,k)-normalizer);
        }

//        if(isnan(vb_data.Phi_m_k.row(el).sum())){
//            std::cerr << "NaN in Phi_m_k post normalization" << std::endl;
//        }
    }
}

void Cavi::update_parameters(const Eigen::MatrixXd & Y_tot, VariationalParameters & vb_data, const AlgorithmParameters & alg_par){
    update_clusters(Y_tot, vb_data, alg_par);
    //std::cout << "Phi_m_k: \n" << vb_data.Phi_m_k << std::endl;
    update_NIW_MIX(Y_tot, vb_data, alg_par);
    /*std::cout << "mu_var_MIX: \n" << vb_data.mu_VAR_MIX << std::endl;
    std::cout << "nu_var_MIX: \n" << vb_data.nu_VAR_MIX << std::endl;
    std::cout << "lambda_var_MIX: \n" << vb_data.lambda_VAR_MIX << std::endl;*/
    update_NIW_DP(Y_tot, vb_data, alg_par);
    /*std::cout << "mu_var_DP: \n" << vb_data.mu_var_DP << std::endl;
    std::cout << "nu_var_DP: \n" << vb_data.nu_var_DP << std::endl;
    std::cout << "lambda_var_DP: \n" << vb_data.lambda_var_DP << std::endl;*/
    update_dirichlet(vb_data, alg_par);
    //std::cout << "eta_k: \n" << vb_data.eta_k << std::endl;
    update_betas(vb_data, alg_par);
    //std::cout << "a_k_beta: \n" << vb_data.a_k_beta << std::endl;
    //std::cout << "b_k_beta: \n" << vb_data.b_k_beta << std::endl;
}
