//
// Created by marta on 25/03/2022.
//

#ifndef VARBRANDCPP2_CAVI_H
#define VARBRANDCPP2_CAVI_H

#include "VBData.h"
#include "ELBO.h"
//#include "root/Utils.h"

#include <iostream>
#include <vector>
#include <tuple>
#include <math.h>

#include "root/lib/eigen-3.4.0/Eigen/Core"
#include "root/lib/eigen-3.4.0/Eigen/Dense"
#include "root/lib/eigen-3.4.0/unsupported/Eigen/SpecialFunctions"

class Cavi {
private:
    const Eigen::MatrixXd& Y_tot;
    VariationalParameters & vb_data;
    const AlgorithmParameters& alg_par;

public:
    Cavi(const Eigen::MatrixXd& Y_tot,
         VariationalParameters & vb_data,
         const AlgorithmParameters & alg_par):
         Y_tot(Y_tot), vb_data(vb_data), alg_par(alg_par){};

    std::vector<double> start();

    void update_parameters(const Eigen::MatrixXd&,
                           VariationalParameters&,
                           const AlgorithmParameters&);
};

#endif //VARBRANDCPP2_CAVI_H
